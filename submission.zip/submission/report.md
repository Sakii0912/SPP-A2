# SPP Assignment 2

## Report by Ayyagari Krishna Saketh - 2023111008

### Preamble - System Specifications and Dataset used

#### System Specifications

- CPU: Intel(R) Core(TM) i7-13700H CPU @ 2.40GHz - 14 Cores, 20 Threads, 45W TDP
- GPU: NVIDIA GeForce RTX 4060 Laptop GPU - 8GB VRAM, 35-115W TDP.
- RAM: 16 GB
- OS: Ubuntu 22.04

#### Dataset

The dataset used is a small subset of the COCO dataset called coco128 containing 128 images.

### Task 1: Inference obtained from the YOLOv5 Models

Using the pre-trained YOLOv5 models

- YOLOv5n: time to run: 1.2s
- YOLOv5s: time to run: 1.2s
- YOLOv5m: time to run: 1.7s
- YOLOv5l: time to run: 2.1s
- YOLOv5x: time to run: 3.4s



#### Latency and Throughput Comparison Table for Pre-trained Model

``` markdown

| Model               | Average Latency (ms) | Average Throughput (FPS)  | Average Inference Time (ms)|
|---------------------|----------------------|---------------------------|----------------------------|
| YOLOv5n             | 51.70                | 21.36135621837091         | 45.52                      |
| YOLOv5s             | 94.90                | 11.484930731025095        | 90.09                      |
| YOLOv5m             | 220.79               | 4.862839262014042         | 215.31                     |
| YOLOv5l             | 412.24               | 2.556861631218234         | 407.02                     |
| YOLOv5x             | 688.30               | 1.542323795823647         | 683.10                     |
| YOLOv5n (Pretrained)| 44.77                | 50.942813055228214        | 37.08                      |
| YOLOv5s (Pretrained)| 70.19                | 42.862158901259036        | 65.83                      |
| YOLOv5m (Pretrained)| 150.32               | 25.10122251631671         | 145.47                     |
| YOLOv5l (Pretrained)| 269.08               | 16.986595993402638        | 263.40                     |
| YOLOv5x (Pretrained)| 452.52               | 10.415510976156353        | 443.34                     |
```
### Task 2: Model information, GFLOPS and roofline analysis

#### Model information and GFLOPS
```markdown

| Model    | Total Parameters | Model Size | GFLOPS| GFLOPS/sec |
|----------|------------------|------------|-------|------------|
| YOLOv5n  | 1,867,405        | 124.14 MB  | 2.25  |    50      |
| YOLOv5s  | 7,225,885        | 240.19 MB  | 8.24  |   99.1     |
| YOLOv5m  | 21,172,173       | 469.24 MB  | 24.48 |   132.2    |
| YOLOv5l  | 46,533,693       | 796.37 MB  | 54.57 |   162.1    |
| YOLOv5x  | 86,705,005       | 1235.18 MB | 102.83|   179.2    |
```

Peak GFLOPS for my machine is $2.4 * 20 * 1.25 * 8 = 480$ GFLOPS. (Assuming 1.25 CPI, 20 threads and AVX2 vectorization).

Memory Bandwidth of my system - $18$ GB/s (calculated in the last assignment)

And,
$$
\text{Utilization} = \frac{\text{Actual GFLOPS}}{\text{Peak GFLOPS}}
$$

Where Actual GFLOPS is the GFLOPS obtained from the model and Peak GFLOPS is the peak GFLOPS of the machine.

Hence, comparing the Utilization for each model, we obtain the following table:
```markdown
| Model    | Actual GFLOPS/sec | Utilization |
|----------|-------------------|-------------|
| YOLOv5n  | 50                | 0.1         |
| YOLOv5s  | 99.1              | 0.198       |
| YOLOv5m  | 132.2             | 0.264       |
| YOLOv5l  | 162.1             | 0.324       |
| YOLOv5x  | 179.2             | 0.358       |
```

#### Roofline analysis

```markdown
| Model    | Operational intensity | OI * Memory Bandwidth | Bound Type       |
|----------|-----------------------|-----------------------|------------------|
| YOLOv5n  | 17.2                  | 314.8                 | Memory Bound     |
| YOLOv5s  | 32.7                  | 598.4                 | Compute Bound    |
| YOLOv5m  | 49.8                  | 911.3                 | Compute  Bound   |
| YOLOv5l  | 65.3                  | 1195                  | Compute  Bound   |
| YOLOv5x  | 79.4                  | 1453                  | Compute  Bound   |
```

The analysis here is a little deceiving, since we are assuming that the whole model fits into our cache, which is just simply impossible. Hence we observe such a discrepancy between calculated GFLOPS/sec and actual GFLOPS/sec (since we are considering no conflict misses in the cache).


#### Bonus: Layer-wise breakdown of the models

`YOLOv5n`

```markdown
| Layer | Type       | FLOPS           | Percentage |
|-------|------------|-----------------|------------|
| conv  | Conv2d     | 1894.0 FLOPS    | 5.726%     |
| conv  | Conv2d     | 1890.72 FLOPS   | 5.716%     |
| conv  | Conv2d     | 1889.08 FLOPS   | 5.711%     |
| conv  | Conv2d     | 1888.24 FLOPS   | 5.709%     |
| conv  | Conv2d     | 1428.68 FLOPS   | 4.319%     |
| conv  | Conv2d     | 947.0 FLOPS     | 2.863%     |
| conv  | Conv2d     | 945.36 FLOPS    | 2.858%     |
| conv  | Conv2d     | 945.36 FLOPS    | 2.858%     |
| conv  | Conv2d     | 945.36 FLOPS    | 2.858%     |
| conv  | Conv2d     | 944.52 FLOPS    | 2.856%     |
| conv  | Conv2d     | 944.52 FLOPS    | 2.856%     |
| conv  | Conv2d     | 944.52 FLOPS    | 2.856%     |
| conv  | Conv2d     | 944.52 FLOPS    | 2.856%     |
| conv  | Conv2d     | 944.52 FLOPS    | 2.856%     |
| conv  | Conv2d     | 944.52 FLOPS    | 2.856%     |
| conv  | Conv2d     | 944.12 FLOPS    | 2.854%     |
| conv  | Conv2d     | 944.12 FLOPS    | 2.854%     |
| conv  | Conv2d     | 944.12 FLOPS    | 2.854%     |
| 0     | Conv2d     | 842.12 FLOPS    | 2.546%     |
| conv  | Conv2d     | 839.68 FLOPS    | 2.539%     |
| conv  | Conv2d     | 426.0 FLOPS     | 1.288%     |
| conv  | Conv2d     | 422.72 FLOPS    | 1.278%     |
| conv  | Conv2d     | 422.72 FLOPS    | 1.278%     |
| conv  | Conv2d     | 421.08 FLOPS    | 1.273%     |
| conv  | Conv2d     | 421.08 FLOPS    | 1.273%     |
| conv  | Conv2d     | 421.08 FLOPS    | 1.273%     |
| conv  | Conv2d     | 421.08 FLOPS    | 1.273%     |
| conv  | Conv2d     | 421.08 FLOPS    | 1.273%     |
| conv  | Conv2d     | 420.24 FLOPS    | 1.271%     |
| conv  | Conv2d     | 420.24 FLOPS    | 1.271%     |
| conv  | Conv2d     | 420.24 FLOPS    | 1.271%     |
| conv  | Conv2d     | 420.24 FLOPS    | 1.271%     |
| 1     | Conv2d     | 419.44 FLOPS    | 1.268%     |
| conv  | Conv2d     | 213.0 FLOPS     | 0.644%     |
| conv  | Conv2d     | 213.0 FLOPS     | 0.644%     |
| conv  | Conv2d     | 211.36 FLOPS    | 0.639%     |
| conv  | Conv2d     | 211.36 FLOPS    | 0.639%     |
| conv  | Conv2d     | 210.52 FLOPS    | 0.636%     |
| conv  | Conv2d     | 210.52 FLOPS    | 0.636%     |
| conv  | Conv2d     | 210.52 FLOPS    | 0.636%     |
| conv  | Conv2d     | 210.52 FLOPS    | 0.636%     |
| conv  | Conv2d     | 210.52 FLOPS    | 0.636%     |
| conv  | Conv2d     | 210.12 FLOPS    | 0.635%     |
| conv  | Conv2d     | 210.12 FLOPS    | 0.635%     |
| conv  | Conv2d     | 210.12 FLOPS    | 0.635%     |
| conv  | Conv2d     | 210.12 FLOPS    | 0.635%     |
| conv  | Conv2d     | 210.12 FLOPS    | 0.635%     |
| conv  | Conv2d     | 210.12 FLOPS    | 0.635%     |
| 2     | Conv2d     | 209.32 FLOPS    | 0.633%     |
| conv  | Conv2d     | 108.12 FLOPS    | 0.327%     |
| conv  | Conv2d     | 106.48 FLOPS    | 0.322%     |
| conv  | Conv2d     | 106.48 FLOPS    | 0.322%     |
| conv  | Conv2d     | 106.48 FLOPS    | 0.322%     |
| conv  | Conv2d     | 105.68 FLOPS    | 0.319%     |
| conv  | Conv2d     | 105.68 FLOPS    | 0.319%     |
| conv  | Conv2d     | 105.68 FLOPS    | 0.319%     |
| conv  | Conv2d     | 105.68 FLOPS    | 0.319%     |
| conv  | Conv2d     | 105.68 FLOPS    | 0.319%     |
| conv  | Conv2d     | 105.28 FLOPS    | 0.318%     |
| conv  | Conv2d     | 105.28 FLOPS    | 0.318%     |
| 15    | Upsample   | 3276.8 FLOPS    | 0.010%     |
| 11    | Upsample   | 1638.4 FLOPS    | 0.005%     |
| m     | MaxPool2d  | 1228.8 FLOPS    | 0.004%     |
```

`YOLOv5s`

```markdown
| Layer | Type       | FLOPS           | Percentage |
|-------|------------|-----------------|------------|
| conv  | Conv2d     | 714.36 FLOPS    | 7.897%     |
| conv  | Conv2d     | 475.12 FLOPS    | 5.253%     |
| conv  | Conv2d     | 473.48 FLOPS    | 5.235%     |
| conv  | Conv2d     | 472.68 FLOPS    | 5.226%     |
| conv  | Conv2d     | 472.28 FLOPS    | 5.221%     |
| 0     | Conv2d     | 424.32 FLOPS    | 4.691%     |
| conv  | Conv2d     | 237.56 FLOPS    | 2.626%     |
| conv  | Conv2d     | 236.76 FLOPS    | 2.617%     |
| conv  | Conv2d     | 236.76 FLOPS    | 2.617%     |
| conv  | Conv2d     | 236.76 FLOPS    | 2.617%     |
| conv  | Conv2d     | 236.32 FLOPS    | 2.613%     |
| conv  | Conv2d     | 236.32 FLOPS    | 2.613%     |
| conv  | Conv2d     | 236.32 FLOPS    | 2.613%     |
| conv  | Conv2d     | 236.32 FLOPS    | 2.613%     |
| conv  | Conv2d     | 236.32 FLOPS    | 2.613%     |
| conv  | Conv2d     | 236.32 FLOPS    | 2.613%     |
| conv  | Conv2d     | 236.12 FLOPS    | 2.610%     |
| conv  | Conv2d     | 236.12 FLOPS    | 2.610%     |
| conv  | Conv2d     | 236.12 FLOPS    | 2.610%     |
| 1     | Conv2d     | 210.52 FLOPS    | 2.327%     |
| conv  | Conv2d     | 210.12 FLOPS    | 2.323%     |
| conv  | Conv2d     | 108.12 FLOPS    | 1.195%     |
| conv  | Conv2d     | 106.48 FLOPS    | 1.177%     |
| conv  | Conv2d     | 106.48 FLOPS    | 1.177%     |
| conv  | Conv2d     | 105.68 FLOPS    | 1.168%     |
| conv  | Conv2d     | 105.68 FLOPS    | 1.168%     |
| conv  | Conv2d     | 105.68 FLOPS    | 1.168%     |
| conv  | Conv2d     | 105.68 FLOPS    | 1.168%     |
| conv  | Conv2d     | 105.68 FLOPS    | 1.168%     |
| conv  | Conv2d     | 105.28 FLOPS    | 1.164%     |
| conv  | Conv2d     | 105.28 FLOPS    | 1.164%     |
| conv  | Conv2d     | 105.28 FLOPS    | 1.164%     |
| conv  | Conv2d     | 105.28 FLOPS    | 1.164%     |
| 2     | Conv2d     | 104.84 FLOPS    | 1.159%     |
| conv  | Conv2d     | 54.08 FLOPS     | 0.598%     |
| conv  | Conv2d     | 54.08 FLOPS     | 0.598%     |
| conv  | Conv2d     | 53.24 FLOPS     | 0.589%     |
| conv  | Conv2d     | 53.24 FLOPS     | 0.589%     |
| conv  | Conv2d     | 52.84 FLOPS     | 0.584%     |
| conv  | Conv2d     | 52.84 FLOPS     | 0.584%     |
| conv  | Conv2d     | 52.84 FLOPS     | 0.584%     |
| conv  | Conv2d     | 52.84 FLOPS     | 0.584%     |
| conv  | Conv2d     | 52.84 FLOPS     | 0.584%     |
| conv  | Conv2d     | 52.64 FLOPS     | 0.582%     |
| conv  | Conv2d     | 52.64 FLOPS     | 0.582%     |
| conv  | Conv2d     | 52.64 FLOPS     | 0.582%     |
| conv  | Conv2d     | 52.64 FLOPS     | 0.582%     |
| conv  | Conv2d     | 52.64 FLOPS     | 0.582%     |
| conv  | Conv2d     | 52.64 FLOPS     | 0.582%     |
| conv  | Conv2d     | 27.84 FLOPS     | 0.308%     |
| conv  | Conv2d     | 27.04 FLOPS     | 0.299%     |
| conv  | Conv2d     | 27.04 FLOPS     | 0.299%     |
| conv  | Conv2d     | 27.04 FLOPS     | 0.299%     |
| conv  | Conv2d     | 26.64 FLOPS     | 0.294%     |
| conv  | Conv2d     | 26.64 FLOPS     | 0.294%     |
| conv  | Conv2d     | 26.64 FLOPS     | 0.294%     |
| conv  | Conv2d     | 26.64 FLOPS     | 0.294%     |
| conv  | Conv2d     | 26.64 FLOPS     | 0.294%     |
| conv  | Conv2d     | 26.4 FLOPS      | 0.292%     |
| conv  | Conv2d     | 26.4 FLOPS      | 0.292%     |
| 15    | Upsample   | 1638.4 FLOPS    | 0.018%     |
| 11    | Upsample   | 819.2 FLOPS     | 0.009%     |
| m     | MaxPool2d  | 614.4 FLOPS     | 0.007%     |
```

`YOLOv5m`

```markdown
| Layer | Type       | FLOPS           | Percentage |
|-------|------------|-----------------|------------|
| conv  | Conv2d     | 4.24 MFLOPS     | 4.337%     |
| conv  | Conv2d     | 4.24 MFLOPS     | 4.332%     |
| conv  | Conv2d     | 4.24 MFLOPS     | 4.330%     |
| conv  | Conv2d     | 4.24 MFLOPS     | 4.329%     |
| conv  | Conv2d     | 2143.04 FLOPS   | 2.184%     |
| conv  | Conv2d     | 2128.28 FLOPS   | 2.169%     |
| conv  | Conv2d     | 2128.28 FLOPS   | 2.169%     |
| conv  | Conv2d     | 2125.84 FLOPS   | 2.166%     |
| conv  | Conv2d     | 2125.84 FLOPS   | 2.166%     |
| conv  | Conv2d     | 2125.84 FLOPS   | 2.166%     |
| conv  | Conv2d     | 2125.84 FLOPS   | 2.166%     |
| conv  | Conv2d     | 2125.84 FLOPS   | 2.166%     |
| conv  | Conv2d     | 2125.84 FLOPS   | 2.166%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.6 FLOPS    | 2.165%     |
| conv  | Conv2d     | 2124.0 FLOPS    | 2.164%     |
| conv  | Conv2d     | 2124.0 FLOPS    | 2.164%     |
| conv  | Conv2d     | 2124.0 FLOPS    | 2.164%     |
| conv  | Conv2d     | 2124.0 FLOPS    | 2.164%     |
| conv  | Conv2d     | 2124.0 FLOPS    | 2.164%     |
| conv  | Conv2d     | 1888.68 FLOPS   | 1.925%     |
| 0     | Conv2d     | 1259.92 FLOPS   | 1.284%     |
| conv  | Conv2d     | 953.56 FLOPS    | 0.972%     |
| conv  | Conv2d     | 948.64 FLOPS    | 0.967%     |
| conv  | Conv2d     | 948.64 FLOPS    | 0.967%     |
| conv  | Conv2d     | 946.16 FLOPS    | 0.964%     |
| conv  | Conv2d     | 946.16 FLOPS    | 0.964%     |
| conv  | Conv2d     | 946.16 FLOPS    | 0.964%     |
| conv  | Conv2d     | 946.16 FLOPS    | 0.964%     |
| conv  | Conv2d     | 946.16 FLOPS    | 0.964%     |
| conv  | Conv2d     | 944.96 FLOPS    | 0.963%     |
| conv  | Conv2d     | 944.96 FLOPS    | 0.963%     |
| conv  | Conv2d     | 944.96 FLOPS    | 0.963%     |
| conv  | Conv2d     | 944.96 FLOPS    | 0.963%     |
| 1     | Conv2d     | 628.32 FLOPS    | 0.640%     |
| conv  | Conv2d     | 476.76 FLOPS    | 0.486%     |
| conv  | Conv2d     | 476.76 FLOPS    | 0.486%     |
| conv  | Conv2d     | 474.32 FLOPS    | 0.483%     |
| conv  | Conv2d     | 474.32 FLOPS    | 0.483%     |
| conv  | Conv2d     | 473.08 FLOPS    | 0.482%     |
| conv  | Conv2d     | 473.08 FLOPS    | 0.482%     |
| conv  | Conv2d     | 473.08 FLOPS    | 0.482%     |
| conv  | Conv2d     | 473.08 FLOPS    | 0.482%     |
| conv  | Conv2d     | 473.08 FLOPS    | 0.482%     |
| conv  | Conv2d     | 472.48 FLOPS    | 0.481%     |
| conv  | Conv2d     | 472.48 FLOPS    | 0.481%     |
| conv  | Conv2d     | 472.48 FLOPS    | 0.481%     |
| conv  | Conv2d     | 472.48 FLOPS    | 0.481%     |
| conv  | Conv2d     | 472.48 FLOPS    | 0.481%     |
| conv  | Conv2d     | 472.48 FLOPS    | 0.481%     |
| 2     | Conv2d     | 313.76 FLOPS    | 0.320%     |
| conv  | Conv2d     | 240.84 FLOPS    | 0.245%     |
| conv  | Conv2d     | 240.84 FLOPS    | 0.245%     |
| conv  | Conv2d     | 238.4 FLOPS     | 0.243%     |
| conv  | Conv2d     | 238.4 FLOPS     | 0.243%     |
| conv  | Conv2d     | 238.4 FLOPS     | 0.243%     |
| conv  | Conv2d     | 238.4 FLOPS     | 0.243%     |
| conv  | Conv2d     | 238.4 FLOPS     | 0.243%     |
| conv  | Conv2d     | 238.4 FLOPS     | 0.243%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 237.16 FLOPS    | 0.242%     |
| conv  | Conv2d     | 236.56 FLOPS    | 0.241%     |
| conv  | Conv2d     | 236.56 FLOPS    | 0.241%     |
| conv  | Conv2d     | 236.56 FLOPS    | 0.241%     |
| conv  | Conv2d     | 236.56 FLOPS    | 0.241%     |
| 15    | Upsample   | 4.92 FLOPS      | 0.005%     |
| 11    | Upsample   | 2457.6 FLOPS    | 0.003%     |
| m     | MaxPool2d  | 1843.2 FLOPS    | 0.002%     |
```

`YOLOv5l`

```markdown
| Layer | Type       | FLOPS           | Percentage |
|-------|------------|-----------------|------------|
| conv  | Conv2d     | 7.56 MFLOPS     | 3.460%     |
| conv  | Conv2d     | 7.56 MFLOPS     | 3.457%     |
| conv  | Conv2d     | 7.56 MFLOPS     | 3.455%     |
| conv  | Conv2d     | 7.56 MFLOPS     | 3.454%     |
| conv  | Conv2d     | 3781.44 FLOPS   | 1.730%     |
| conv  | Conv2d     | 3781.44 FLOPS   | 1.730%     |
| conv  | Conv2d     | 3781.44 FLOPS   | 1.730%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3778.16 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3776.52 FLOPS   | 1.728%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3775.68 FLOPS   | 1.727%     |
| conv  | Conv2d     | 3357.08 FLOPS   | 1.536%     |
| conv  | Conv2d     | 2857.36 FLOPS   | 1.307%     |
| conv  | Conv2d     | 1690.84 FLOPS   | 0.773%     |
| conv  | Conv2d     | 1684.28 FLOPS   | 0.770%     |
| conv  | Conv2d     | 1684.28 FLOPS   | 0.770%     |
| conv  | Conv2d     | 1681.0 FLOPS    | 0.769%     |
| conv  | Conv2d     | 1681.0 FLOPS    | 0.769%     |
| conv  | Conv2d     | 1681.0 FLOPS    | 0.769%     |
| conv  | Conv2d     | 1681.0 FLOPS    | 0.769%     |
| conv  | Conv2d     | 1681.0 FLOPS    | 0.769%     |
| conv  | Conv2d     | 1679.36 FLOPS   | 0.768%     |
| conv  | Conv2d     | 1679.36 FLOPS   | 0.768%     |
| conv  | Conv2d     | 1679.36 FLOPS   | 0.768%     |
| conv  | Conv2d     | 1679.36 FLOPS   | 0.768%     |
| 0     | Conv2d     | 1677.68 FLOPS   | 0.767%     |
| conv  | Conv2d     | 845.4 FLOPS     | 0.387%     |
| conv  | Conv2d     | 845.4 FLOPS     | 0.387%     |
| conv  | Conv2d     | 842.12 FLOPS    | 0.385%     |
| conv  | Conv2d     | 842.12 FLOPS    | 0.385%     |
| conv  | Conv2d     | 840.48 FLOPS    | 0.384%     |
| conv  | Conv2d     | 840.48 FLOPS    | 0.384%     |
| conv  | Conv2d     | 839.68 FLOPS    | 0.384%     |
| conv  | Conv2d     | 839.68 FLOPS    | 0.384%     |
| conv  | Conv2d     | 839.68 FLOPS    | 0.384%     |
| conv  | Conv2d     | 839.68 FLOPS    | 0.384%     |
| conv  | Conv2d     | 840.48 FLOPS    | 0.384%     |
| conv  | Conv2d     | 840.48 FLOPS    | 0.384%     |
| conv  | Conv2d     | 840.48 FLOPS    | 0.384%     |
| conv  | Conv2d     | 839.68 FLOPS    | 0.384%     |
| conv  | Conv2d     | 839.68 FLOPS    | 0.384%     |
| 1     | Conv2d     | 837.2 FLOPS     | 0.383%     |
| conv  | Conv2d     | 426.0 FLOPS     | 0.195%     |
| conv  | Conv2d     | 426.0 FLOPS     | 0.195%     |
| conv  | Conv2d     | 426.0 FLOPS     | 0.195%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 422.72 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 421.08 FLOPS    | 0.193%     |
| conv  | Conv2d     | 420.24 FLOPS    | 0.192%     |
| conv  | Conv2d     | 420.24 FLOPS    | 0.192%     |
| conv  | Conv2d     | 420.24 FLOPS    | 0.192%     |
| conv  | Conv2d     | 420.24 FLOPS    | 0.192%     |
| conv  | Conv2d     | 420.24 FLOPS    | 0.192%     |
| conv  | Conv2d     | 420.24 FLOPS    | 0.192%     |
| 2     | Conv2d     | 418.2 FLOPS     | 0.191%     |
| 15    | Upsample   | 6.56 FLOPS      | 0.003%     |
| m     | MaxPool2d  | 2457.6 FLOPS    | 0.001%     |
| 11    | Upsample   | 3276.8 FLOPS    | 0.001%     |
```

`YOLOv5x`

```markdown
| Layer | Type       | FLOPS           | Percentage |
|-------|------------|-----------------|------------|
| conv  | Conv2d     | 11.8 MFLOPS     | 2.869%     |
| conv  | Conv2d     | 11.8 MFLOPS     | 2.867%     |
| conv  | Conv2d     | 11.8 MFLOPS     | 2.866%     |
| conv  | Conv2d     | 11.8 MFLOPS     | 2.865%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.434%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.434%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.434%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.434%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.92 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.88 MFLOPS     | 1.433%     |
| conv  | Conv2d     | 5.24 MFLOPS     | 1.274%     |
| conv  | Conv2d     | 3571.72 FLOPS   | 0.867%     |
| conv  | Conv2d     | 2637.84 FLOPS   | 0.641%     |
| conv  | Conv2d     | 2629.64 FLOPS   | 0.639%     |
| conv  | Conv2d     | 2629.64 FLOPS   | 0.639%     |
| conv  | Conv2d     | 2625.52 FLOPS   | 0.638%     |
| conv  | Conv2d     | 2625.52 FLOPS   | 0.638%     |
| conv  | Conv2d     | 2625.52 FLOPS   | 0.638%     |
| conv  | Conv2d     | 2625.52 FLOPS   | 0.638%     |
| conv  | Conv2d     | 2625.52 FLOPS   | 0.638%     |
| conv  | Conv2d     | 2623.48 FLOPS   | 0.637%     |
| conv  | Conv2d     | 2623.48 FLOPS   | 0.637%     |
| conv  | Conv2d     | 2623.48 FLOPS   | 0.637%     |
| conv  | Conv2d     | 2623.48 FLOPS   | 0.637%     |
| 0     | Conv2d     | 2095.48 FLOPS   | 0.509%     |
| conv  | Conv2d     | 1318.92 FLOPS   | 0.320%     |
| conv  | Conv2d     | 1318.92 FLOPS   | 0.320%     |
| conv  | Conv2d     | 1314.8 FLOPS    | 0.319%     |
| conv  | Conv2d     | 1314.8 FLOPS    | 0.319%     |
| conv  | Conv2d     | 1312.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1312.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1311.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1311.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1311.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1311.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1312.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1312.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1312.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1311.76 FLOPS   | 0.319%     |
| conv  | Conv2d     | 1311.76 FLOPS   | 0.319%     |
| 1     | Conv2d     | 1046.12 FLOPS   | 0.254%     |
| conv  | Conv2d     | 663.56 FLOPS    | 0.161%     |
| conv  | Conv2d     | 663.56 FLOPS    | 0.161%     |
| conv  | Conv2d     | 663.56 FLOPS    | 0.161%     |
| conv  | Conv2d     | 663.56 FLOPS    | 0.161%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 659.44 FLOPS    | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 657.4 FLOPS     | 0.160%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| conv  | Conv2d     | 656.4 FLOPS     | 0.159%     |
| 2     | Conv2d     | 522.64 FLOPS    | 0.127%     |
| 15    | Upsample   | 8.2 FLOPS       | 0.002%     |
| m     | MaxPool2d  | 3072.0 FLOPS    | 0.001%     |
| 11    | Upsample   | 4.08 FLOPS      | 0.001%     |
```

### Task 3: Code Profiling & Hotspot Identification

Doing the code profiling on the YOLOv5s model.

Used tools: `PyTorch Profiler` and `line_profile`

### `PyTorch Profiler` Results:

`YOLOv5s`

CPU Profiler

```markdown
-------------------------------------------------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------
                                                   Name    Self CPU %      Self CPU   CPU total %     CPU total  CPU time avg     Self CUDA   Self CUDA %    CUDA total  CUDA time avg       CPU Mem  Self CPU Mem      CUDA Mem  Self CUDA Mem    # of Calls
-------------------------------------------------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------  ------------
                                           aten::conv2d         1.87%      10.838ms        48.10%     278.655ms      36.283us       0.000us         0.00%     252.097ms      32.825us           0 b           0 b       9.56 Gb           0 b          7680
                                      aten::convolution         1.94%      11.224ms        46.23%     267.817ms      34.872us       0.000us         0.00%     252.097ms      32.825us           0 b           0 b       9.56 Gb           0 b          7680
                                     aten::_convolution         5.46%      31.636ms        44.29%     256.593ms      33.411us       0.000us         0.00%     252.097ms      32.825us           0 b           0 b       9.56 Gb       1.12 Mb          7680
                                aten::cudnn_convolution        20.19%     116.973ms        28.67%     166.107ms      21.629us     216.167ms        64.83%     216.167ms      28.147us           0 b           0 b       9.56 Gb       9.56 Gb          7680
                                       cudaLaunchKernel        18.27%     105.865ms        18.27%     105.865ms       2.808us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b         37697
                                            aten::copy_         2.06%      11.919ms         9.70%      56.194ms      14.270us      19.281ms         5.78%      19.281ms       4.896us           0 b           0 b           0 b           0 b          3938
                                               aten::to         0.25%       1.435ms         8.76%      50.777ms      23.399us       0.000us         0.00%      12.103ms       5.578us     176.16 Kb     -11.70 Kb     558.30 Mb           0 b          2170
                                         aten::_to_copy         0.58%       3.336ms         8.51%      49.289ms      38.689us       0.000us         0.00%      12.103ms       9.500us     176.18 Kb           0 b     558.30 Mb           0 b          1274
                                             aten::add_         4.50%      26.093ms         7.89%      45.708ms       5.952us      35.925ms        10.77%      35.925ms       4.678us           0 b           0 b           0 b           0 b          7680
                                            aten::silu_         3.06%      17.751ms         6.24%      36.161ms       4.956us      18.567ms         5.57%      18.567ms       2.545us           0 b           0 b           0 b           0 b          7296
                                              aten::cat         3.82%      22.104ms         6.02%      34.886ms      13.300us      17.815ms         5.34%      17.815ms       6.792us           0 b           0 b       4.68 Gb       4.68 Gb          2623
                                            aten::index         1.44%       8.356ms         5.23%      30.327ms      34.152us       1.930ms         0.58%       3.369ms       3.794us           0 b           0 b       3.80 Mb       3.61 Mb           888
                                  cudaStreamSynchronize         4.26%      24.706ms         4.26%      24.706ms      19.393us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          1274
                                       torchvision::nms         0.89%       5.174ms         4.19%      24.265ms     192.579us     827.764us         0.25%       2.779ms      22.055us           0 b    -243.05 Kb      63.00 Kb    -619.50 Kb           126
                                           aten::arange         0.85%       4.909ms         3.27%      18.926ms      10.585us     720.032us         0.22%       1.440ms       0.805us           0 b           0 b       1.03 Mb        -512 b          1788
                                        cudaMemcpyAsync         3.14%      18.170ms         3.14%      18.170ms      10.491us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          1732
                                          aten::nonzero         1.07%       6.191ms         3.01%      17.460ms      68.739us       1.439ms         0.43%       1.439ms       5.664us           0 b           0 b     212.50 Kb           0 b           254
                                              aten::mul         1.79%      10.376ms         2.75%      15.955ms       8.046us       2.816ms         0.84%       2.816ms       1.420us           0 b           0 b      73.45 Mb      73.45 Mb          1983
                                          aten::reshape         1.11%       6.439ms         2.46%      14.267ms       1.617us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          8824
                                         cuLaunchKernel         2.41%      13.971ms         2.41%      13.971ms       2.722us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          5132
                                             aten::sort         0.62%       3.621ms         2.31%      13.365ms      53.036us       1.411ms         0.42%       2.458ms       9.752us           0 b           0 b     359.00 Kb     152.00 Kb           252
                                              aten::add         1.44%       8.370ms         2.28%      13.221ms       6.908us       3.186ms         0.96%       3.186ms       1.664us           0 b           0 b     937.65 Mb     937.65 Mb          1914
                                           aten::select         1.51%       8.723ms         1.79%      10.370ms       1.695us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          6118
                                            aten::clone         0.25%       1.423ms         1.67%       9.692ms      15.192us       0.000us         0.00%       5.196ms       8.144us           0 b           0 b     792.18 Mb           0 b           638
                                              aten::div         1.05%       6.079ms         1.61%       9.323ms       8.149us       1.964ms         0.59%       1.964ms       1.717us           0 b           0 b     447.04 Mb     447.04 Mb          1144
                                             aten::view         1.54%       8.904ms         1.54%       8.904ms       0.811us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b         10973
                                          aten::argsort         0.04%     253.579us         1.35%       7.814ms      62.019us       0.000us         0.00%       1.240ms       9.838us           0 b           0 b     111.50 Kb     -60.00 Kb           126
                                              aten::sub         0.82%       4.766ms         1.24%       7.212ms       8.700us       1.032ms         0.31%       1.032ms       1.245us           0 b           0 b      15.58 Mb      15.58 Mb           829
                                       aten::contiguous         0.08%     442.114us         1.13%       6.547ms      17.048us       0.000us         0.00%       4.916ms      12.802us           0 b           0 b     791.94 Mb           0 b           384
                                    aten::empty_strided         1.04%       6.052ms         1.04%       6.052ms       3.961us       0.000us         0.00%       0.000us       0.000us     176.18 Kb     176.18 Kb     558.54 Mb     558.54 Mb          1528
                                            aten::stack         0.17%       1.012ms         0.96%       5.586ms      17.401us       0.000us         0.00%     642.257us       2.001us           0 b           0 b       5.12 Mb           0 b           321
                                            aten::slice         0.74%       4.295ms         0.94%       5.456ms       1.346us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          4054
                                        cudaEventRecord         0.93%       5.360ms         0.93%       5.360ms       0.698us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          7680
                                            aten::empty         0.86%       4.990ms         0.86%       4.990ms       2.059us       0.000us         0.00%       0.000us       0.000us      80.66 Kb      80.44 Kb     792.15 Mb     792.15 Mb          2424
                                       aten::as_strided         0.82%       4.741ms         0.82%       4.741ms       0.315us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b         15032
                                       aten::max_pool2d         0.14%     821.746us         0.81%       4.706ms      12.255us       0.000us         0.00%       4.033ms      10.504us           0 b           0 b     156.13 Mb    -132.11 Mb           384
                                              aten::pow         0.53%       3.099ms         0.77%       4.489ms      11.690us     370.664us         0.11%     370.664us       0.965us           0 b           0 b      18.30 Mb      18.30 Mb           384
                          aten::max_pool2d_with_indices         0.47%       2.706ms         0.67%       3.884ms      10.115us       4.033ms         1.21%       4.033ms      10.504us           0 b           0 b     333.28 Mb     333.28 Mb           384
                                          aten::type_as         0.03%     198.696us         0.66%       3.841ms      30.007us       0.000us         0.00%       1.717ms      13.413us           0 b           0 b     446.58 Mb           0 b           128
                                    cudaLaunchKernelExC         0.66%       3.832ms         0.66%       3.832ms       2.739us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          1399
                                           aten::clamp_         0.38%       2.176ms         0.63%       3.673ms       7.174us     609.902us         0.18%     609.902us       1.191us           0 b           0 b           0 b           0 b           512
                                           aten::narrow         0.28%       1.638ms         0.63%       3.656ms       2.861us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          1278
                                               aten::gt         0.41%       2.361ms         0.59%       3.409ms      13.419us     419.052us         0.13%     419.052us       1.650us           0 b           0 b       2.36 Mb       2.36 Mb           254
                                          aten::sigmoid         0.37%       2.155ms         0.58%       3.336ms       8.687us       1.562ms         0.47%       1.562ms       4.067us           0 b           0 b     790.54 Mb     790.54 Mb           384
                                        cudaMemsetAsync         0.57%       3.316ms         0.57%       3.316ms       0.686us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          4834
                                       aten::index_put_         0.08%     447.586us         0.55%       3.158ms      12.338us       0.000us         0.00%     471.466us       1.842us           0 b           0 b           0 b           0 b           256
                               aten::upsample_nearest2d         0.35%       2.025ms         0.52%       3.039ms      11.870us       1.672ms         0.50%       1.672ms       6.530us           0 b           0 b     479.89 Mb     479.89 Mb           256
                                       aten::empty_like         0.19%       1.079ms         0.51%       2.957ms       5.799us       0.000us         0.00%       0.000us       0.000us           0 b           0 b     792.12 Mb           0 b           510
                                         aten::meshgrid         0.25%       1.470ms         0.47%       2.748ms       8.562us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           321
                                 aten::_index_put_impl_         0.28%       1.616ms         0.47%       2.711ms      10.589us     471.466us         0.14%     471.466us       1.842us           0 b           0 b           0 b           0 b           256
                                          aten::resize_         0.42%       2.455ms         0.42%       2.455ms       1.927us       0.000us         0.00%       0.000us       0.000us           0 b           0 b     908.00 Kb     908.00 Kb          1274
                                     aten::index_select         0.21%       1.196ms         0.41%       2.399ms      19.040us     267.974us         0.08%     267.974us       2.127us           0 b           0 b     167.50 Kb           0 b           126
                                              aten::max         0.27%       1.536ms         0.35%       2.024ms      16.065us     410.190us         0.12%     410.190us       3.255us           0 b           0 b     187.00 Kb     187.00 Kb           126
                                           aten::expand         0.26%       1.480ms         0.34%       1.996ms       1.554us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          1284
                                             aten::sub_         0.18%       1.049ms         0.31%       1.778ms       6.944us     235.185us         0.07%     235.185us       0.919us           0 b           0 b           0 b           0 b           256
                                  cudaStreamIsCapturing         0.30%       1.712ms         0.30%       1.712ms       0.223us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          7680
                                  cudaStreamGetPriority         0.29%       1.703ms         0.29%       1.703ms       0.222us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          7680
                                   cudaFuncSetAttribute         0.28%       1.596ms         0.28%       1.596ms       0.540us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          2957
                                 aten::split_with_sizes         0.21%       1.221ms         0.27%       1.593ms       4.148us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           384
                                            aten::zeros         0.07%     426.685us         0.26%       1.503ms      11.740us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           128
                       cudaDeviceGetStreamPriorityRange         0.25%       1.464ms         0.25%       1.464ms       0.191us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          7680
                                 cudaDeviceGetAttribute         0.24%       1.388ms         0.24%       1.388ms       0.238us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          5838
                                          aten::permute         0.11%     659.134us         0.18%       1.036ms       2.699us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           384
                                             aten::mul_         0.10%     597.887us         0.17%     976.058us       7.746us     175.616us         0.05%     175.616us       1.394us           0 b           0 b           0 b           0 b           126
                                             aten::div_         0.10%     567.681us         0.16%     938.487us       7.332us     146.564us         0.04%     146.564us       1.145us           0 b           0 b           0 b           0 b           128
                                                aten::t         0.06%     342.435us         0.14%     827.134us       3.256us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           254
                                        aten::unsqueeze         0.10%     586.275us         0.14%     790.836us       1.232us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           642
                                            aten::zero_         0.06%     330.320us         0.13%     778.048us       6.079us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           128
                                             aten::set_         0.11%     656.802us         0.11%     656.802us       2.586us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           254
                                           Buffer Flush         0.08%     482.064us         0.09%     495.628us      49.563us       7.776us         0.00%       7.776us       0.778us      11.69 Kb      11.69 Kb    -207.00 Kb    -207.00 Kb            10
                                        aten::transpose         0.07%     393.038us         0.08%     484.699us       1.908us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           254
                                    cudaPeekAtLastError         0.08%     476.128us         0.08%     476.128us       0.078us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b          6132
                                            aten::fill_         0.08%     447.728us         0.08%     447.728us       3.498us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           128
                                           aten::unbind         0.03%     180.117us         0.07%     411.952us       3.218us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           128

cudaOccupancyMaxActiveBlocksPerMultiprocessorWithFlags         0.06%     340.111us         0.06%     340.111us       0.525us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           648
cudaFuncGetAttributes                                          0.03%     156.056us         0.03%     156.056us       3.185us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b            49
aten::alias                                                   0.02%     141.835us         0.02%     141.835us       1.108us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           128
aten::lift_fresh                                              0.02%     138.201us         0.02%     138.201us       0.180us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           768
aten::result_type                                             0.02%     114.990us         0.02%     114.990us       0.299us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           384
aten::detach_                                                 0.01%      53.936us         0.01%      53.936us       0.421us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b           128
cudaDeviceSynchronize                                         0.00%      11.811us         0.00%      11.811us      11.811us       0.000us         0.00%       0.000us       0.000us           0 b           0 b           0 b           0 b             1
Memcpy HtoD (Pageable -> Device)                              0.00%       0.000us         0.00%       0.000us       0.000us      10.062ms         3.02%      10.062ms      11.255us           0 b           0 b           0 b           0 b           894

void at::native::unrolled_elementwise_kernel<at::native::...  0.00%       0.000us         0.00%       0.000us       0.000us       1.891ms         0.57%       1.891ms       7.445us           0 b           0 b           0 b           0 b           254
void at::native::vectorized_elementwise_kernel<4, at::native::... 0.00%       0.000us         0.00%       0.000us       0.000us     954.140us         0.29%     954.140us       2.385us           0 b           0 b           0 b           0 b           400
void implicit_convolve_sgemm<float, float, 128, 5, 5...       0.00%       0.000us         0.00%       0.000us       0.000us      14.909ms         4.47%      14.909ms     116.474us           0 b           0 b           0 b           0 b           128
void at::native::elementwise_kernel<128, 2, at::native::...   0.00%       0.000us         0.00%       0.000us       0.000us      37.184ms        11.15%      37.184ms       4.257us           0 b           0 b           0 b           0 b          8734
void at::native::vectorized_elementwise_kernel<4, at::native::... 0.00%       0.000us         0.00%       0.000us       0.000us      18.567ms         5.57%      18.567ms       2.545us           0 b           0 b           0 b           0 b          7296
void cask__5x_cudnn::computeOffsetsKernel<false, false...     0.00%       0.000us         0.00%       0.000us       0.000us     156.231us         0.05%     156.231us       1.260us           0 b           0 b           0 b           0 b           124
_5x_cudnn_ampere_scudnn_128x64_relu_medium_nn_v1               0.00%       0.000us         0.00%       0.000us       0.000us      12.608ms         3.78%      12.608ms     101.681us           0 b           0 b           0 b           0 b           124
ampere_sgemm_128x32_nn                                        0.00%       0.000us         0.00%       0.000us       0.000us       2.940ms         0.88%       2.940ms      12.051us           0 b           0 b           0 b           0 b           244
void cudnn::winograd::generateWinogradTilesKernel<0,...       0.00%       0.000us         0.00%       0.000us       0.000us     977.079us         0.29%     977.079us       1.978us           0 b           0 b           0 b           0 b           494
_5x_cudnn_ampere_scudnn_winograd_128x128_ldg1_ldg4_r...       0.00%       0.000us         0.00%       0.000us       0.000us      17.336ms         5.20%      17.336ms      35.093us           0 b           0 b           0 b           0 b           494
void at::native::vectorized_elementwise_kernel<4, at::native::... 0.00%       0.000us         0.00%       0.000us       0.000us       2.440ms         0.73%       2.440ms       1.906us           0 b           0 b           0 b           0 b          1280
void at::native::(anonymous namespace)::CatArrayBatch...      0.00%       0.000us         0.00%       0.000us       0.000us      11.634ms         3.49%      11.634ms       6.991us           0 b           0 b           0 b           0 b          1664
void cutlass::Kernel2<cutlass_80_tensorop_s1688gemm_...       0.00%       0.000us         0.00%       0.000us       0.000us      10.485ms         3.14%      10.485ms      11.650us           0 b           0 b           0 b           0 b           900
void cudnn::engines_precompiled::nchwToNhwcKernel<fl...       0.00%       0.000us         0.00%       0.000us       0.000us      23.629ms         7.09%      23.629ms       7.583us           0 b           0 b           0 b           0 b          3116
sm86_xmma_fprop_implicit_gemm_indexed_tf32f32_tf32f3...       0.00%       0.000us         0.00%       0.000us       0.000us       8.379ms         2.51%       8.379ms      67.575us           0 b           0 b           0 b           0 b           124
void cutlass::Kernel2<cutlass_80_tensorop_s1688gemm_...       0.00%       0.000us         0.00%       0.000us       0.000us      28.930ms         8.68%      28.930ms      13.582us           0 b           0 b           0 b           0 b          2130
void cutlass__5x_cudnn::Kernel<cutlass_tensorop_s168...       0.00%       0.000us         0.00%       0.000us       0.000us       9.033ms         2.71%       9.033ms      58.653us           0 b           0 b           0 b           0 b           154
```

Self CPU time total: 579.343ms
Self CUDA time total: 333.454ms

#### `Difference between CPU and CUDA time:` 245.889ms

### `line_profiler` Results:

#### `YOLOv5s`

Timer unit: 1e-09 s

Total time: 10.5091 s

File: /tmp/ipykernel_20890/1432606016.py

Function: batch_inference at line 1

Timer unit: 1e-09 s

Total time: 1.04621 s

File: /tmp/ipykernel_10140/1538104890.py

Function: `inference` at line 1

```markdown
| Line # | Hits | Time (ns)      | Per Hit (ns) | % Time | Line Contents                     |
|--------|------|----------------|--------------|--------|-----------------------------------|
| 1      | 1    | 759.0          | 759.0        | 0.0    | `def inference(model, dataset):` |
| 2      | 1    | 759.0          | 759.0        | 0.0    | `results = []`                   |
| 3      | 129  | 58,374.0       | 452.5        | 0.0    | `for image in dataset:`          |
| 4      | 128  | 1,046,044,878.0| 8,179,101.5  | 100.0  | `result = model(image)`          |
| 5      | 128  | 103,690.0      | 810.1        | 0.0    | `results.append(result)`         |
| 6      | 1    | 127.0          | 127.0        | 0.0    | `return results`                 |
```

#### Percentage time spent in each pipeline component

The table obtained from PyTorch profiler gives a breakdown of the time percentages spent in each function. We can see that most of the time is spent in the actual inference (convolutions) and at `aten::copy()` which is the copy operation from CPU to GPU. The `aten::copy_` function is responsible for transferring data between CPU and GPU memory, and it takes a significant amount of time in the pipeline (around 9% in CPU and 5% in GPU).



### Task 4: Optimization

#### Method 1: PyTorch Quantization

Dynamic quantization implemented since it is much simpler to do so, even though it is not as effective as static quantization. It reduces the size by using less precise data types (int8 instead of float32) for the model weights and activations. This can lead to a significant reduction in model size and can also speed up inference on CPUs.


### `Line Profiler` Results

#### `YOLOv5s`

Timer unit: 1e-09 s

Total time: 0.882439 s

File: /tmp/ipykernel_10140/1538104890.py
```markdown
| Line # | Hits | Time (ns)      | Per Hit (ns) | % Time | Line Contents                     |
|--------|------|----------------|--------------|--------|-----------------------------------|
| 1      | 1    | 1,261.0        | 1,261.0      | 0.0    | def inference(model, dataset):   |
| 2      | 1    | 1,261.0        | 1,261.0      | 0.0    | results = []                     |
| 3      | 129  | 47,664.0       | 369.5        | 0.0    | for image in dataset:            |
| 4      | 128  | 882,296,146.0  | 7,000,000.0  | 100.0  | result = model(image)            |
| 5      | 128  | 93,361.0       | 729.4        | 0.0    | results.append(result)           |
| 6      | 1    | 112.0          | 112.0        | 0.0    | return results                   |
```

#### Method 2: Using Mixed precision

Mixed precision is a technique that uses both 16-bit and 32-bit floating-point types in a model during training and inference. This can result in better performance especially in GPUs that support this conversion due to lesser number of computations needed.

`YOLOv5s`

Timer unit: 1e-09 s

Total time: 0.912288 s

File: /tmp/ipykernel_10140/1538104890.py
```markdown
| Line # | Hits | Time (ns)      | Per Hit (ns) | % Time | Line Contents                     |
|--------|------|----------------|--------------|--------|-----------------------------------|
| 1      | 1    | 538.0          | 538.0        | 0.0    | def inference(model, dataset):   |
| 2      | 1    | 538.0          | 538.0        | 0.0    | results = []                     |
| 3      | 129  | 51,676.0       | 400.6        | 0.0    | for image in dataset:            |
| 4      | 128  | 912,131,186.0  | 7,000,000.0  | 100.0  | result = model(image)            |
| 5      | 128  | 104,765.0      | 818.5        | 0.0    | results.append(result)           |
| 6      | 1    | 114.0          | 114.0        | 0.0    | return results                   |
```

### Method 3: Multi threading

Multi-Threading allows parallel computation of multiple images at once. This can significantly speed up the inference time when the computation is available.

`YOLOv5s`

Timer unit: 1e-09 s

Total time: 0.686038 s

File: /tmp/ipykernel_10140/2676164376.py

```markdown
| Line # | Hits | Time (ns)     | Per Hit (ns) | % Time | Line Contents                                   |
|--------|------|---------------|--------------|--------|------------------------------------------------|
| 4      |      |               |              |        | `def inference_threaded(model, dataset, num_threads=4):` |
| 5      | 1    | 1,007.0       | 1,007.0      | 0.0    | `results = []`                                 |
| 7      | 2    | 216,745.0     | 108,372.5    | 0.0    | `with ThreadPoolExecutor(max_workers=num_threads) as executor:` |
| 8      | 1    | 10,321,283.0  | 10,321,283.0 | 1.5    | `future_to_image = {executor.submit(process_single_image, model, image): image for image in dataset}` |
| 10     | 129  | 77,074.0      | 597.5        | 0.0    | `for future in future_to_image:`              |
| 11     | 128  | 23,422.0      | 183.0        | 0.0    | `try:`                                        |
| 12     | 128  | 674,995,877.0 | 5,273,405.3  | 98.4   | `result = future.result()`                    |
| 13     | 124  | 115,996.0     | 935.5        | 0.0    | `results.append(result)`                      |
| 14     | 4    | 4,658.0       | 1,164.5      | 0.0    | `except Exception as e:`                      |
| 15     | 4    | 281,223.0     | 70,305.8     | 0.0    | `print(f"Error processing image: {e}")`       |
| 17     | 1    | 225.0         | 225.0        | 0.0    | `return results`                              |
```

### Method 4 (Extra): half precision and multi threading

Just a bit of fun. Results obtained is between the two methods above.

`YOLOv5s`

Timer unit: 1e-09 s

Total time: 0.752944 s

File: /tmp/ipykernel_10140/2676164376.py

```markdown
| Line # | Hits | Time (ns)     | Per Hit (ns) | % Time | Line Contents                                   |
|--------|------|---------------|--------------|--------|------------------------------------------------|
| 4      |      |               |              |        | `def inference_threaded(model, dataset, num_threads=4):` |
| 5      | 1    | 706.0         | 706.0        | 0.0    | `results = []`                                 |
| 7      | 2    | 262,536.0     | 131,268.0    | 0.0    | `with ThreadPoolExecutor(max_workers=num_threads) as executor:` |
| 8      | 1    | 16,349,944.0  | 16,349,944.0 | 2.2    | `future_to_image = {executor.submit(process_single_image, model, image): image for image in dataset}` |
| 10     | 129  | 64,480.0      | 499.8        | 0.0    | `for future in future_to_image:`              |
| 11     | 128  | 19,271.0      | 150.6        | 0.0    | `try:`                                        |
| 12     | 128  | 735,771,326.0 | 5,749,764.3  | 97.7   | `result = future.result()`                    |
| 13     | 126  | 91,885.0      | 729.2        | 0.0    | `results.append(result)`                      |
| 14     | 2    | 2,172.0       | 1,086.0      | 0.0    | `except Exception as e:`                      |
| 15     | 2    | 380,958.0     | 190,479.0    | 0.1    | `print(f"Error processing image: {e}")`       |
| 17     | 1    | 250.0         | 250.0        | 0.0    | `return results`                              |
```

#### Comparing between the methods:

- **Original**: 1.04621 s = Baseline performance
- **PyTorch Quantization (Dynamic)**: 0.882439 s = 12% improvement
- **Mixed Precision**: 0.912288 s = 9% improvement
- **Multi-threading**: 0.686038 s = 32% improvement
- **Half Precision + Multi-threading**: 0.752944 s = 25% improvement

![Comparing Optimization Methods](Optimization_Comparision.png)

#### Performance per watt anaylsis

TDP of the GPU can be varied between 35 and 115 Watts. Taking an average of 70 Watts for the GPU and 45 Watts for the CPU, total power consumption is 115 Watts.

We have seen the average GFLOPS/sec in the second task.

Hence the performance per watt is calculated as: GFLOPS per second / Total Power Consumption = $99.1 / 115 = 0.86$ for the YOLOv5s model that we have used above

For the remaining models, we have the following table

```markdown
| Model         | GFLOPS | Power Consumption (W) | Performance per Watt |
|---------------|--------|-----------------------|----------------------|
| YOLOv5n       | 50.0   | 115                   | 0.43                 |
| YOLOv5s       | 99.1   | 115                   | 0.86                 |
| YOLOv5m       | 132.2  | 115                   | 1.14                 |
| YOLOv5l       | 162.1  | 115                   | 1.41                 |
| YOLOv5x       | 179.2  | 115                   | 1.55                 |
```

### Summary

![Slide 1](slide1.png)
![Slide 2](slide2.png)
![Slide 3](slide3.png)
![Slide 4](slide4.png)
![Slide 5](slide5.png)



